---
name: SAMI SPORTS
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1b1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#d7c2c1'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#9f8c8c'
  outline-variant: '#524343'
  surface-tint: '#ffb3b2'
  primary: '#ffdad9'
  on-primary: '#512122'
  primary-container: '#ffb3b2'
  on-primary-container: '#7b4243'
  inverse-primary: '#894e4e'
  secondary: '#5cdf86'
  on-secondary: '#003918'
  secondary-container: '#0aa655'
  on-secondary-container: '#003114'
  tertiary: '#ffddb8'
  on-tertiary: '#472a00'
  tertiary-container: '#ffb95f'
  on-tertiary-container: '#754900'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ffb3b2'
  on-primary-fixed: '#370d0f'
  on-primary-fixed-variant: '#6d3737'
  secondary-fixed: '#7afc9f'
  secondary-fixed-dim: '#5cdf86'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005226'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-score:
    fontFamily: IBM Plex Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
  display-score-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 26px
  title-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-match-status:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-navigation:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system embodies an elite, broadcast-grade sports intelligence environment. It is tailored for high-intensity digital sports coverage, encompassing real-time match streaming, dynamic analytics, lightning-fast live score feeds, and premium sports editorial journalism.

### Core Character & Philosophy
- **Identity:** Confident, Technical, Sports-First, Premium, Fast, and Uncompromisingly Clear.
- **Visual Style:** Technical High-Contrast Dark Mode. The interface uses deep obsidian tiers to carve out structural depths, punctuated by high-visibility stadium accents and precise numerical data readouts.
- **Bi-Directional Fluency:** Engineered Arabic RTL-first with native support for Latin alphanumeric data, international club typography, and global league entity naming conventions. Numerical readouts, match clocks, and statistical tallies maintain strict tabular visual alignment across both writing systems.
- **Emotional Response:** Inspires urgency and immersion akin to sitting front-row at a stadium broadcast control room—delivering authoritative data precision alongside vivid live-action media.

## Colors

The palette establishes an aggressive 80-15-5 dark architectural hierarchy: 75–85% deep container surfaces, 10–20% high-legibility textual data, and ~5% intentional live broadcast signal accents.

### Palette Architecture & Semantic Tokens
- **Canvas & Surfaces:**
  - `background` / `surface` / `surface-dim`: `#0f131d` (Core arena darkness)
  - `surface-container-lowest`: `#0a0e17` (Deep recessed wells, match video player chassis)
  - `surface-container-low`: `#171c25` (Subtle grouped segment backings)
  - `surface-container`: `#1b2029` (Standard fixture cards, table rows)
  - `surface-container-high`: `#262a34` (Hover elevations, active match tabs, popovers)
  - `surface-container-highest`: `#31353f` (Modal backdrops, prominent toolbars)
  - `surface-bright`: `#353944` (Elevated micro-panels)
  - `surface-variant`: `#31353f`
- **Text & Hierarchy:**
  - `on-surface` / `on-background`: `#dfe2f0` (Primary readability level: team names, scores, headlines)
  - `on-surface-variant`: `#e6bdbb` (Subtext, league groups, secondary timestamps)
  - `inverse-surface`: `#dfe2f0`
  - `inverse-on-surface`: `#2c303b`
- **Broadcast Accents & Semantic Signals:**
  - **Live Action Crimson (`primary` / `primary-container`):** `#ffb3b2` and `#ff525d` (`on-primary`: `#680013`, `on-primary-container`: `#5b000f`, `inverse-primary`: `#bf002b`). Applied strictly to active live match pulses, breakaways, red cards, and high-priority stream triggers.
  - **Match Success Pitch Green (`secondary` / `secondary-container`):** `#7dffa2` and `#05e777` (`on-secondary`: `#003918`, `on-secondary-container`: `#00622e`). Applied to on-target milestones, match wins, upward momentum stats, and clean sheets.
  - **Tactical Alert Amber (`tertiary` / `tertiary-container`):** `#ffb95f` and `#ca8100` (`on-tertiary`: `#472a00`, `on-tertiary-container`: `#3e2400`). Applied to yellow card alerts, upcoming kick-offs, and critical notifications.
  - **Structural Contours:** `outline`: `#ad8887` (Active interactive borders), `outline-variant`: `#5d3f3f` (Resting match partition borders).
  - **Critical Failure (`error`):** `#ffb4ab` (`error-container`: `#93000a`, `on-error`: `#690005`, `on-error-container`: `#ffdad6`).

## Typography

The typography is built around **IBM Plex Sans** paired seamlessly with **IBM Plex Sans Arabic**. This combination ensures geometric clarity across match engines, statistical matrices, and journalism layouts.

### Usage Directives
- **Tabular Figures:** Always render scores, match clocks (`90+4'`), player squad numbers, and standings tables with monospaced numerical metrics (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during real-time data syncs.
- **Bilingual Typographic Balancing:**
  - Arabic text inherits native baseline vertical adjustments from IBM Plex Sans Arabic to retain balanced line-height parity with Latin team abbreviations (e.g., "RMA vs BAR").
  - Maintain strict optical hierarchy: `display-score` drives the center-stage score ticker, while `label-match-status` delivers micro-capsule updates (`LIVE`, `FT`, `HT`, `VAR`).

## Layout & Spacing

The layout model is driven by an adaptive fluid grid optimized for high-density information architecture, multi-game streaming split-screens, and fast vertical scanning.

### Grid & Breakpoints
- **Desktop (1200px+):** 12-column layout with 24px margins (`margin-desktop`) and 16px gutters (`gutter`). Supports a three-column split: left navigation / league selectors, center match visualizer / video player, and right-hand real-time tactical statistics feed.
- **Tablet (768px – 1199px):** 8-column layout with 16px margins and 16px gutters. Collapses the tactical panel into tabbed switchers under the primary feed.
- **Mobile (320px – 767px):** 4-column layout with 16px margins (`margin`) and 12px gutters (`gutter-mobile`). Live scores pin to an edge-to-edge horizontal carousel with dense vertical news feeds below.

### Spatial Discipline
- `space-xs` (4px): Micro gaps between club crest badges and abbreviation text; inner padding for live badges.
- `space-sm` (8px): Spacing between stat bar meters, chip gaps, and condensed table cells.
- `space-md` (12px): Standard internal card padding for match fixture modules.
- `space-lg` (16px): Section header margins, match summary paddings, and media module spacing.
- `space-xl` (24px): Structural section divisions separating distinct tournament brackets and live streams.

## Elevation & Depth

Visual depth is produced using **Tonal Layers** accented by structural **Low-Contrast Outlines** and ambient colored glows. Standard blurred drop shadows are minimized to maintain crisp readability on OLED panels and high-refresh sports displays.

### Layering Hierarchy
1. **Foundation Level (0dp):** `surface` (`#0f131d`) and `surface-container-lowest` (`#0a0e17`) form the bedrock background and streaming chassis.
2. **Structural Tiles (1dp):** `surface-container` (`#1b2029`) bordered by `1px solid #5d3f3f` (opacity matched via `outline-variant`). Used for fixture rows, league tables, and article cards.
3. **Floating Fixtures & Active States (2dp):** `surface-container-high` (`#262a34`) bordered by `outline` (`#ad8887`). Used for pinned live match trackers and hovered items.
4. **Overlays & Drawers (3dp):** `surface-container-highest` (`#31353f`) complemented by an ambient outer glow of `0 8px 32px rgba(0, 0, 0, 0.6)`. Used for live stream chat windows, match filter sheets, and notification modals.

### Broadcast Signal Lighting
Active live matches feature an ambient edge-glow using Live Red Accent (`#FF525D` at 15% opacity: `box-shadow: 0 0 16px rgba(255, 82, 93, 0.15)`), signaling real-time match events without disrupting adjacent content.

## Shapes

The geometric architecture uses a calibrated **Rounded (Level 2)** geometry to balance technical efficiency with modern visual polish.

### Shape Scale
- **Radius Sm (`4px`):** Stat distribution bars, team color tags, score pills, and tabular data indicators.
- **Radius Default (`8px`):** Primary buttons, text input fields, match fixture items, and table headers.
- **Radius Md (`12px`):** Featured live match cards, tactical field visualizers, and news article media containers.
- **Radius Lg (`16px`):** Video streaming viewports, comprehensive tournament brackets, and modal dialogue containers.
- **Radius Xl (`24px`):** Hero match spotlight modules and floating action docks.
- **Radius Full (`9999px`):** Live badges, category chips, player avatar frames, and circular match clock counters.

## Components

### Buttons
- **Primary Live / Action:** Surface `#ff525d`, text `#5b000f` (`on-primary-container`), weight `700`, radius `8px`. Hover lifts with brightness filter (1.08) and subtle live glow.
- **Secondary / Ghost:** Surface `surface-container-high` (`#262a34`), border `1px solid` `outline-variant` (`#5d3f3f`), text `on-surface` (`#dfe2f0`). Hover shifts background to `surface-bright` (`#353944`).
- **Interactive State Feedback:** Active click triggers scale reduction (`0.98`). RTL setups flip icon prefixes to maintain correct directional alignment.

### Match Fixture Cards
- Structured within `surface-container` (`#1b2029`) with an 8px radius and a 1px `outline-variant` border.
- Features split team rows with 24px crest placeholders, team typography in `headline-md`, and central score readouts rendered in `display-score` (`IBM Plex Sans` tabular).
- In live states, the fixture card's leading edge displays a 3px accent strip in `#ff525d`, paired with a pulsing 6px beacon dot.

### Chips & Filter Tabs
- **Default State:** Container `surface-container-low` (`#171c25`), text `on-surface` (`#dfe2f0`), font `label-navigation`, radius `9999px`.
- **Selected State:** Container `surface-bright` (`#353944`), border `1px solid #ffb3b2`, text `#ffb3b2`.
- Used for navigating leagues (e.g., دوري روشن, UEFA Champions League, Premier League).

### Live Status Badges
- Pill-shaped (`rounded-full`), padding `2px 8px`, font `label-match-status`.
- **Live Active:** Background `rgba(255, 82, 93, 0.15)`, text `#ff525d`, accompanied by a CSS radar pulse dot.
- **Finished / Upcoming:** Background `surface-container-highest` (`#31353f`), text `on-surface-variant` (`#e6bdbb`).

### Data Tables & Standings
- Row height fixed at 44px for high scannability. Alternate row backgrounds use `surface` (`#0f131d`) and `surface-container-low` (`#171c25`).
- Goal difference and points columns rendered in bold weight with monospaced tabular figures. Top qualifying positions feature a 2px left border (or right border in RTL) tinted in Success Green (`#05e777`).

### Input Fields
- Container `surface-container-lowest` (`#0a0e17`), border `1px solid #5d3f3f`, text `on-surface` (`#dfe2f0`), radius `8px`.
- Focused state transitions border to `outline` (`#ad8887`) with a subtle `#ffb3b2` outer halo (2px ring at 20% opacity). RTL search inputs place the magnifying glass icon on the right with trailing clear buttons on the left.